import { createAuthClient } from "better-auth/react";
import { expoClient } from "@better-auth/expo/client";
import * as SecureStore from "expo-secure-store";


import { getBaseUrl } from "@/lib/get-base-url";

export const authClient = createAuthClient({
  baseURL: getBaseUrl(),
  plugins: [
    expoClient({
      scheme: "gofood",
      storagePrefix: "gofood",
      storage: SecureStore,
    }),
  ],
});