import { authClient } from "@/lib/auth-client";
import { getBaseUrl } from "@/lib/get-base-url";

let cachedCookie: string | null = null;

authClient.useSession;

export function refreshCookieCache() {
  cachedCookie = authClient.getCookie();
}

export async function apiFetch(path: string, options: RequestInit = {}) {
  if (!cachedCookie) {
    cachedCookie = authClient.getCookie();
  }

  return fetch(`${getBaseUrl()}${path}`, {
    ...options,
    credentials: "omit",
    headers: {
      ...options.headers,
      Cookie: cachedCookie ?? '',
      "Content-Type": "application/json",
    },
  });
}