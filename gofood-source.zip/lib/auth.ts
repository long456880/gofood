import { betterAuth } from "better-auth";
import { expo } from "@better-auth/expo";
import { Pool } from "pg";
const pool = new Pool({
  connectionString: process.env.DATABASE_URL,
});
export const auth = betterAuth({
  database: pool,
  emailAndPassword: {
    enabled: true,
  },
  trustedOrigins: ["gofood://", "exp://", "exp://**"],
  socialProviders: {
    google: {
      clientId: process.env.GOOGLE_CLIENT_ID as string,
      clientSecret: process.env.GOOGLE_CLIENT_SECRET as string,
    },
  },
  plugins: [expo()],
  databaseHooks: {
    user: {
      create: {
        after: async (user) => {
          await pool.query(
            `INSERT INTO profiles (id, username, points) VALUES ($1, $2, 0)`,
            [user.id, user.name]
          );
        },
      },
    },
  },
});