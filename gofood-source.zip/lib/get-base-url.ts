import Constants from "expo-constants";

export const getBaseUrl = () => {
  const debuggerHost = Constants.expoConfig?.hostUri;
  const localhost = debuggerHost?.split(":")[0];
  if (!localhost) {
    return "http://localhost:8081";
  }
  return `http://${localhost}:8081`;
};