import { auth } from "@/lib/auth";
import { db } from "@/lib/db";

export async function POST(request: Request) {
  const session = await auth.api.getSession({ headers: request.headers });
  if (!session) return Response.json({ error: "Not signed in" }, { status: 401 });

  const body = await request.json();
  const { username, currentPassword, newPassword } = body;

  if (username) {
    await db.query(
      `UPDATE profiles SET username = $1 WHERE id = $2`,
      [username, session.user.id]
    );
    await db.query(
      `UPDATE "user" SET name = $1 WHERE id = $2`,
      [username, session.user.id]
    );
  }

  if (currentPassword && newPassword) {
    try {
      await auth.api.changePassword({
        headers: request.headers,
        body: {
          currentPassword,
          newPassword,
          revokeOtherSessions: false,
        },
      });
    } catch (err) {
      return Response.json({ error: 'Current password is incorrect' }, { status: 400 });
    }
  }

  return Response.json({ success: true });
}