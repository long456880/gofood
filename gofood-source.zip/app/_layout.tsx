import { Stack } from 'expo-router';
import { StatusBar } from 'expo-status-bar';
import 'react-native-reanimated';
import { View, ActivityIndicator } from 'react-native';
import { useEffect } from 'react';
import { authClient } from '@/lib/auth-client';
import { ThemeProvider, useTheme } from '@/lib/theme-context';
import { refreshCookieCache } from '@/lib/api-fetch';
import '@/lib/i18n';

function RootNavigation() {
  const { data: session, isPending } = authClient.useSession();
  const { dark } = useTheme();

  useEffect(() => {
    if (session) refreshCookieCache();
  }, [session]);

  if (isPending) {
    return (
      <View style={{ flex: 1, alignItems: 'center', justifyContent: 'center', backgroundColor: dark ? '#111' : '#fff' }}>
        <ActivityIndicator size="large" color="#D62828" />
      </View>
    );
  }

  return (
    <>
        <Stack screenOptions={{ contentStyle: { backgroundColor: dark ? '#1E1E1E' : '#FFFFFF' } }}>
        <Stack.Protected guard={!!session}>
          <Stack.Screen name="(tabs)" options={{ headerShown: false }} />
          <Stack.Screen name="modal" options={{ presentation: 'modal', title: 'Modal' }} />
          <Stack.Screen name="recipe/[id]" options={{ headerShown: false }} />
          <Stack.Screen name="edit-profile" options={{ headerShown: false }} />
          
        </Stack.Protected>
        <Stack.Protected guard={!session}>
          <Stack.Screen name="sign-in" options={{ headerShown: false }} />
          <Stack.Screen name="sign-up" options={{ headerShown: false }} />
        </Stack.Protected>
      </Stack>
      <StatusBar style={dark ? 'light' : 'dark'} />
    </>
  );
}

export default function RootLayout() {
  return (
    <ThemeProvider>
      <RootNavigation />
    </ThemeProvider>
  );
}